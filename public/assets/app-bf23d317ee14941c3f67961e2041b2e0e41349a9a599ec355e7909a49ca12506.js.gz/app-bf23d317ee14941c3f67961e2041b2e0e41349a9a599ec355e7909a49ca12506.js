
alert('COUCOU');

let centralButton = document.getElementById("centralButton");
let block = document.querySelector('section');

centralButton.onclick = function() {
  this.style.visibility = "hidden";
  block.style.visibility = "visible";
}

setTimeout(function() {
	alert("Hey le site xxxvidsxxx est trop bien. Viens dessus stp please");
},10000);

